VAP Worker handoff
Files:
- worker.js
- poc_runner_sqlmap.py
- payload_job-20251002-0001.json

Run:
1. npm install
2. export vars from .env.example or set env
3. node worker.js

Security: don't enable intrusive options without written authorization.
